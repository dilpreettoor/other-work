package com.example.macstudent.melody;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by macstudent on 2018-04-23.
 */

public class PlayerAdapter extends BaseAdapter {
    private Context mContext;
    LayoutInflater layoutInflater;
    int totalContacts=0;
    TextView txtTrack;
    ImageView imgTrack;
    ArrayList<String> arTrackName;
    public ArrayList<Integer> arTrackImage = new ArrayList<Integer>();

    public PlayerAdapter(Context c) {

        mContext = c;

        arTrackName = new ArrayList<String>();
        layoutInflater = (LayoutInflater.from(c));
        arTrackName.add("Hello");

        arTrackImage.add(R.drawable.image1);
        arTrackImage.add(R.drawable.image2);
        arTrackImage.add(R.drawable.image3);
        arTrackName.add("Me2");
        arTrackName.add("Boss Baby");

    }
    @Override
    public int getCount() {
        return arTrackName.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        convertView = layoutInflater.inflate(R.layout.music_item,null);

        txtTrack = convertView.findViewById(R.id.txtTrack);
        txtTrack.setText(String.valueOf(arTrackName.get(position)));

        /*txtPhone = convertView.findViewById(R.id.txtPhoneNo);
        txtPhone.setText(arPhone.get(position));*/
        String rsName = (String.valueOf(arTrackName.get(position)));




        imgTrack = convertView.findViewById(R.id.imgTrack);
        imgTrack.setImageResource(arTrackImage.get(position));
        //imgTrack.setBackgroundResource(R.drawable.image1);

        return convertView;
    }
    private class Item
    {
        final String name;
        final int drawableId;

        Item(String name, int drawableId)
        {
            this.name = name;
            this.drawableId = drawableId;
        }
    }
}
