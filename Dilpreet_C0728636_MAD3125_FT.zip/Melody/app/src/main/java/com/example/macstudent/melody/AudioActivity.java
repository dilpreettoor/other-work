package com.example.macstudent.melody;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class AudioActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    private int startTime = 0;
    private int finalTime = 0;
    private Handler myHandler = new Handler();
    private int seekTime = 5000;
    SeekBar seekBarProgress;
    TextView txtDuration;
    ImageButton imgPlay, imgPause, imgForward, imgRewind,imgStop ;
    ImageView imgAlbum;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mediaPlayer.stop();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);



        seekBarProgress = (SeekBar)findViewById(R.id.seekBarProgress);
        imgPause = findViewById(R.id.imgPause);
        imgAlbum = findViewById(R.id.imgAlbum);
        imgAlbum.setBackgroundResource(R.drawable.image3);

        imgPlay = findViewById(R.id.imgPlay);
        imgForward = findViewById(R.id.imgForward);
        imgRewind = findViewById(R.id.imgRewind);
        imgStop = findViewById(R.id.imgStop);

        //Create MediaPlayer
        mediaPlayer = MediaPlayer.create(getApplicationContext(),
                R.raw.dichotomy);
        finalTime = mediaPlayer.getDuration();
        startTime = mediaPlayer.getCurrentPosition();
        seekBarProgress.setMax((int) finalTime);


        txtDuration = (TextView)findViewById(R.id.txtDuration);

        imgStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.seekTo(0);
                mediaPlayer.pause();
            }
        });

        imgPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.start();
                seekBarProgress.setProgress((int)startTime);
                myHandler.postDelayed(UpdateSongTime,100);
            }
        });

        imgPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.pause();
            }
        });

        imgForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if(currentPosition + seekTime <= mediaPlayer.getDuration()){
                    mediaPlayer.seekTo(currentPosition + seekTime);
                }else{
                    mediaPlayer.seekTo(mediaPlayer.getDuration());
                }
            }
        });

        imgRewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if(currentPosition - seekTime >= 0){
                    mediaPlayer.seekTo(currentPosition - seekTime);
                }else{
                    mediaPlayer.seekTo(0);
                }
            }
        });

    }

    private Runnable UpdateSongTime = new Runnable() {
        public void run() {
            startTime = mediaPlayer.getCurrentPosition();
            txtDuration.setText(String.format("%d min, %d sec",
                    TimeUnit.MILLISECONDS.toMinutes((long) startTime),
                    TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.
                                    toMinutes((long) startTime)))
            );
            seekBarProgress.setProgress((int)startTime);
            myHandler.postDelayed(this, 100);
        }
    };
}
