//
//  main.swift
//  Protocols_Implementation
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
/*
var obj1 = TestA()
obj1.n1 = 25
obj1.display()

obj1.displayValue()


var obj3 : iDisplay = TestA()
obj3.display()

obj3 = obj1 as TestA
obj3.display()


var obj4 = TestB()
obj4.n1=150
obj4.n2=250
obj4.display()
obj4.iDisplayValue()

var obj5 = Arithmatic(n1: 150, n2: 111)
obj5.calculate()
*/

/*
 
-------------------Arithmatic Operarion-------------------------
print("Enter Number1:")
let n01 = Int(readLine()!)
print("Enter Number2:")
let n02 = Int(readLine()!)

var calc = Operation(n1: n01!, n2: n02!)
calc.calculate()

 -------------------Arithmatic Operarion ends-------------------------
*/



//-------------------------------------Using Double Extension
/*
 let oneInch = 25.4.mm
print("One inch is \(oneInch) meters")

let threeFeet = 3.ft
print("Three Feet is \(threeFeet) meters")

let aMarathon = 42.5.km + 195.m
print("A marathon is \(aMarathon) meters long")
*/
//-------------------------------------Using Double Extension

var str = "HELLO"
print(str.length)
print(str.vowels)



