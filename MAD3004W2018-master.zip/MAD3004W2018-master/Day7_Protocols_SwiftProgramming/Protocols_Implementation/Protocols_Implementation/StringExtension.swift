//
//  StringExtension.swift
//  Protocols_Implementation
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

extension String {
    var length: Int {
        get {
            return self.count
        }
    }
    func contains(s: String) -> Bool
    {
        return true
    }
    var vowels: [String]
    {
        get {
            return ["a","e","i","o","u","A","E","I","O","U"]
        }
    }

}

