//
//  TestB.swift
//  Protocols_Implementation
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class TestB : TestA {
    var n2: Int?

    override func display() {
        print("I am printing from Class B")
    }
    
    func iDisplayValue()
    {
        print("Value of N2: ",self.n2!)
    }
}
