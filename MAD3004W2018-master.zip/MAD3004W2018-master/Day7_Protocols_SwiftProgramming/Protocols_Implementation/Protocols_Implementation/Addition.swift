//
//  Addition.swift
//  Protocols_Implementation
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Operation: Arithmatic {
    var oper: Character?

/*
    init(n01: Int, n02: Int, oper: Character) {
        super.init(n1: n01, n2: n2)
        self.oper = oper
        
    }
 */
    required init(n1: Int, n2: Int)
    {
       super.init(n1: n1, n2: n2)
        
    }
    
    override func calculate()
    {
        print("Enter the Arithmatic Operator:")
        oper = Character(readLine()!)
        if oper == "+"
        {
            print("Addition:", n1+n2)
        }
        else if oper == "-"
        {
            print("Subtraction:", n1-n2)
        }
        else if oper == "*"
        {
            print("Multiplication:", n1*n2)
        }
        else if oper == "/"
        {
            print("Division:", n1/n2)
        }
        else
        {
            print("Invalid Input")
        }
    }
    
}

