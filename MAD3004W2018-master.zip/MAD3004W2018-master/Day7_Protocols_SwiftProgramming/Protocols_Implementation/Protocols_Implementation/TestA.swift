//
//  TestA.swift
//  Protocols_Implementation
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class TestA: iDisplay, iDisplayValue {
    var n1: Int=200
    
    func display() {
        print("I am printing from class TestA")
    }
    
    func displayValue ()
    {
        print("Value of N1:",self.n1)
    }
    
}
