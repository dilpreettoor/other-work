//
//  main.swift
//  Day7_PrimeNumber_Task
//
//  Created by MacStudent on 2018-02-06.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
var num: Int?
print("Enter any number:")
num = Int(readLine()!)

var otpt = num!.prima

print(otpt)



