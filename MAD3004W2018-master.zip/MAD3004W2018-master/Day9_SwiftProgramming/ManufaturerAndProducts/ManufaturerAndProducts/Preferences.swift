//
//  Preferences.swift
//  ManufaturerAndProducts
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class preference: vehicle {
    
    var prefer = false
    var description: String {
        var Output = "Do you prefer \(noOfWheels) wheel vehicles from \(name)?"
        Output += prefer ? "Y" : "N"
        return Output
    }
    
}
