//
//  License.swift
//  License Task
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class license : Person {
    var LicLoc: String?
    var FeeDeposited: Double?
    
    override init() {
        super.init()
        self.LicLoc = ""
        self.FeeDeposited = 0.0
    }
    
    init?(Nm: String, Addrs: String, Ag: Int, LL: String, Fee: Double)
    {
        if Ag < 16 {
            return nil
        }
        else
        {
            super.init(Nm: Nm, Addrs: Addrs, Ag: Ag)
            self.LicLoc = LL
            self.FeeDeposited = Fee
        }
    }
    
    func display()
    {
    print("**************Final Detail**************")
        print("Name:",self.Name!)
        print("Address",self.Address!)
        print("Age:",self.Age!)
        print("License Test Location:",self.LicLoc!)
        print("Fee Deposited:", self.FeeDeposited!)
    }
}
