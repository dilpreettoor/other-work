//
//  main.swift
//  License Task
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Enter Name:")
let name = readLine()

print("Enter Address:")
let addrs = readLine()

print("Enter Age:")
let age = Int(readLine()!)

print("Enter License Location:")
let LL = readLine()

print("Enter Fee Deposited:")
let fee = Double(readLine()!)

var licobj = license(Nm: name!, Addrs: addrs!, Ag: age!, LL: LL!, Fee: fee!)

if licobj == nil
{
    print("License can't be applied, Age is Less then 16years")
}
else
{
licobj!.display()
}
