//
//  main.swift
//  Day9_SwiftProgramming
//
//  Created by MacStudent on 2018-02-08.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

let laptop = Product(name: "Laptops")


if let machine = laptop {
    print("Product Name is", machine.name)
}


let anonmachine = Product (name: "")

if anonmachine == nil {
    print("Anon Machine could not be intialized")
}


var prdcrt = cartItem(name: "PC", quantity: 12)
print("Name of Product in Cart is", prdcrt.name)
print("Quantity of Product in cart:",prdcrt.quantity)


