//: Playground - noun: a place where people can play

import UIKit

//Array Declaration
var a = [10,20,30,40,50,60]
print("a[0]: \(a[0])")

let j1 = [110,120]
print ("j1:",j1)

var b = [Int]()
print("size of array b:",b.count)


//Inserting values into array

b.append(100)
print("b[0]: \(b[0])")
print("size of array b:",b.count)

b.append(150)
print("b[1]: \(b[1])")

//Updating value in array
b[0]=250
print("Array B:",b)
print("size of array b:",b.count)

//Assigning Defualt values in array
var num1 = [Int](repeating: 1, count: 5)
print("Num1 Array:",num1)

var num2 = [Int](repeating: 5, count: 15)
print("Num1 Array:",num2)

var nummrg = num1+num2
print("NumMrg:",nummrg)

//Declaring multiple data types

var c = [Any]()
print("Size of C Array:",c.count)
c.append(30)
c.append(150)
c.append(25.36)
c.append("NV")
print("Print C Array:",c)



var x = a[1...5]
for t in x {
    print ("x:",t)
}


//String Array and for each with (Key, Value)
var shopping: [String] = ["Eggs","Milk","Flr"]
for (index, value) in shopping.enumerated() {
    print("Item \(index): \(value)")
}

 //combining array
    
    shopping += ["Water","Daal","Gheyo"]
    print(shopping)

shopping.insert ("Two Eggs",at: 0)
print(shopping)

let mapleSyrup = shopping.remove(at: 2)
print(shopping)

print(mapleSyrup)




// Declaring Set


var grades: Set<Character> = []
grades.insert("A")
grades.insert("B")
grades.insert("C")
grades.insert("D")
grades.insert("E")

print("Grades:",grades)
print("Grades no of counts:",grades.count)



// var gradetype: Set <Any> = []
var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip hop"]
print("I have \(favoriteGenres.count) favorite music genres.")

print(favoriteGenres)


if favoriteGenres.isEmpty {
    print("As far as music goes, I'm not picky.")
} else {
    print("I have particular music preferences.")
}
favoriteGenres.insert("Jazz")

print(favoriteGenres)

if let removedGenre = favoriteGenres.remove("Rock") {
    print("\(removedGenre)? I'm over it.")
} else {
    print("I never much cared for that.")
}


//Finding Content

if favoriteGenres.contains("Funk") {
    print("I get up on the good foot.")
} else {
    print("It's too funky in here.")
}
// Prints "It's too funky in here."



//Sroting of data
for genre in favoriteGenres {
    print("\(genre)")
}
for genre in favoriteGenres.sorted() {
    print("\(genre)")
}





let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

oddDigits.union(evenDigits).sorted()
oddDigits.intersection(evenDigits).sorted()
oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()



let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

houseAnimals.isSubset(of: farmAnimals)
farmAnimals.isSuperset(of: houseAnimals)
farmAnimals.isDisjoint(with: cityAnimals)





