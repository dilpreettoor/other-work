//
//  Payroll.swift
//  MADT_ORG
//
//  Created by MacStudent on 2018-02-02.
//  Copyright © 2018 NAVEEN. All rights reserved.
//

import Foundation

class Payroll: PermanentEmployee {
    var finalPay: Double?
    
    override init() {
        super.init()
        self.finalPay = 0
    }
    
    init (eeID: Int, eeNM: String, eePay: Double, eeVW: Int)
    {
        super.init(eID: eeID, eNM: eeNM, ePay: eePay, eVW: eeVW)
        if (eeVW > 5)
        {
            self.finalPay = eePay - 100
        }
        else
        {
            self.finalPay = eePay
        }
    }
    
    override func display() {                                  //Override keyword to define same function is sub class
        super.display()                                         //super keyword to call the function from base class
        print ("Emp Final pay:",self.finalPay!)
        
    }
}
