//
//  Employee.swift
//  MADT_ORG
//
//  Created by MacStudent on 2018-02-02.
//  Copyright © 2018 NAVEEN. All rights reserved.
//

import Foundation


//Classes
class Employee {
    var empID: Int?
    var empName: String?
    var basicPay: Double?
    
    //Initializers
    init() {
        self.empID = 0
        self.empName = ""
        self.basicPay = 0.0
    }
    
    
    //Parameter Initializers
    
    init(ID: Int, NM: String, Pay: Double){
        self.empID = ID
        self.empName = NM
        self.basicPay = Pay
    }
    
    func display()
    {
        print("Emp ID:",self.empID!)
        print("Emp Name:",self.empName!)
        print("Basic Pay:",self.basicPay!)
    }
}


