//
//  main.swift
//  MADT_ORG
//
//  Created by MacStudent on 2018-02-02.
//  Copyright © 2018 NAVEEN. All rights reserved.
//

import Foundation



//manipulate Object Array[]
print("Enter Number of Emps:")
let NoEmps = Int(readLine()!)

var ID: Int?
var Name: String?
var Pay: Double?
var VW: Int?

var janPayroll = [Payroll]()

for i in 0..<NoEmps! {
    
    print("Enter Detail of Emp ",i+1)
    print("Enter Emp ID:")
    ID = Int(readLine()!)
    print("Enter Emp Name:")
    Name = readLine()
    print("Enter Emp Basic Pay:")
    Pay = Double(readLine()!)
    print("Enter Emp Vacation Weeks:")
    VW = Int(readLine()!)



    janPayroll.append(Payroll(eeID: ID!, eeNM: Name!, eePay: Pay!, eeVW: VW!))
}

for i in 0..<NoEmps! {
    print("--------------------------------")
    print("Detail of Emp ",i+1)
    print("--------------------------------")
    janPayroll[i].display()

}


