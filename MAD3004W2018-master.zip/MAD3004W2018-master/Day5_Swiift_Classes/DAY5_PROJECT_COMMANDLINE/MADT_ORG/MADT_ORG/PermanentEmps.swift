//
//  PermanentEmps.swift
//  MADT_ORG
//
//  Created by MacStudent on 2018-02-02.
//  Copyright © 2018 NAVEEN. All rights reserved.
//

import Foundation


//Inharitance of class

class PermanentEmployee : Employee {
    var vacationWeeks : Int?
    
    override init() {
        super.init()
        self.vacationWeeks = 0
    }
    
    init (eID: Int, eNM: String, ePay: Double, eVW: Int)
    {
        super.init(ID: eID, NM: eNM, Pay: ePay)
        self.vacationWeeks = eVW
        
    }
    
    override func display() {                                  //Override keyword to define same function is sub class
        super.display()                                         //super keyword to call the function from base class
        print ("Emp VacationWeeks:",vacationWeeks!)
    }
    
}

