//: Playground - noun: a place where people can play

import UIKit

//Classes
class Employee {
    var empID: Int?
    var empName: String?
    var basicPay: Double?
    
    //Initializers
    init() {
        self.empID = 0
        self.empName = ""
        self.basicPay = 0.0
    }
    
    
    //Parameter Initializers
    
    init(ID: Int, NM: String, Pay: Double){
        self.empID = ID
        self.empName = NM
        self.basicPay = Pay
    }
    
    func display()
    {
        print("Emp ID:",self.empID!)
        print("Emp Name:",self.empName!)
        print("Basic Pay:",self.basicPay!)
    }
}

//Object Creation
var emp1 = Employee()

emp1.empName = "Naveen"
emp1.empID = 307145
emp1.basicPay = 2556.45

emp1.display()


print("-------------------------------------------------------")

var emp2 = Employee()
emp2.display()

print("-------------------------------------------------------")

var emp3 = Employee(ID: 123, NM: "Sahil", Pay: 25.65)
emp3.display()

print("-------------------------------------------------------")

//Inharitance of class

class PermanentEmployee : Employee {
    var vacationWeeks : Int?

    override init() {
        super.init()
        self.vacationWeeks = 0
    }
    
    init (eID: Int, eNM: String, ePay: Double, eVW: Int)
    {
        super.init(ID: eID, NM: eNM, Pay: ePay)
        self.vacationWeeks = eVW
        
    }
    
   override func display() {                                  //Override keyword to define same function is sub class
        super.display()                                         //super keyword to call the function from base class
        print ("Emp VacationWeeks:",vacationWeeks!)
    }
    
}

var obj2 = PermanentEmployee()
obj2.display()

print("-------------------------------------------------------")

obj2.vacationWeeks = 10
obj2.empName = "Ajit"
obj2.empID = 12345
obj2.basicPay = 13457.84
obj2.display()

print("-------------------------------------------------------")

var obj3 = PermanentEmployee(eID: 258, eNM: "Abhijit", ePay: 3698.36, eVW: 5)

obj3.display()



print("-------------------------------------------------------")

class Payroll: PermanentEmployee {
    var finalPay: Double?
    
    override init() {
        super.init()
        self.finalPay = 0
    }
    
    init (eeID: Int, eeNM: String, eePay: Double, eeVW: Int)
    {
        super.init(eID: eeID, eNM: eeNM, ePay: eePay, eVW: eeVW)
        if (eeVW > 5)
        {
           self.finalPay = eePay - 100
        }
        else
        {
            self.finalPay = eePay
        }
    }
    
    override func display() {                                  //Override keyword to define same function is sub class
        super.display()                                         //super keyword to call the function from base class
        print ("Emp Final pay:",self.finalPay!)
       
}
}



var emp5 = Payroll(eeID: 5899, eeNM: "Amrti", eePay: 1556.67, eeVW: 8)

emp5.display()


print("-------------------------------------------------------")


var emp6 = Payroll(eeID: 4799, eeNM: "ABCD", eePay: 4578.58, eeVW: 4)

emp6.display()


print("-------------------------------------------------------")



//manipulate Object Array[]

var janPayroll = [Payroll]()
let NoEmps = 2

for i in 0..<2 {
    janPayroll.append(Payroll(eeID: 107, eeNM: "JK", eePay: 555.56, eeVW: 7))
    janPayroll[i].display()
}

