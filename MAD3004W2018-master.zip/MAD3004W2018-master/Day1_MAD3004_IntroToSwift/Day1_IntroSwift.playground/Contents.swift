//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)
print("String to be printed with qoutes")       //Print Commands

print("String to be Print : \(str)")            //Print with text and Variables

print("Next String to be Print on same line: \(str)", terminator:" ")   //Defining the last character with terminator

print("1","2","3","4","5", separator: "---")  //Defining Separator in between each string

print("\n","1","2","3","4","5", separator: "\n")     //Putting new line with separator

var n1 = 10
print("N1 variable value",n1)

var n2 = 20

print("N2 variable value:",n2)

var sum = n1 + n2

print("n1+n2=",sum)

/*
n1 = "Test"
print("N1 String:",n1)
*/

var test = "string"
print("Test String:",test)

var n3:Int = 15
print("N3 Value:",n3)

var greet:String = "Good Morning"
print("Greet String:",greet)

var n4:Float = 25.123456789
print("N4 Float Value:",n4)

var n5:Double = 69.456789456
print("N5 Double Value:",n5)

// Find Emojis with ctrl+command+space
var emoji = "😎"
print ("It's an emoji",emoji)

print("\(emoji) with glasses")

//Declaring Constant Variable with Let Keyword

let 🦉 = "Ullu da Patha"
print (🦉)


//Declaring optional data type

let mynum:Int?
mynum = 10

if mynum != nil {
    print("My Num=",mynum!)
}
else
{
    print("My Num is Nil")
}


//Converting DataTypes String to Int only when There's Numeric Values in String

let possiblenumber = "1234"
let convertednumber:Int?

convertednumber = Int(possiblenumber)

if convertednumber != nil {
    print("Converted Number:", convertednumber!)
    print ("New Con Number: ",convertednumber!+5)
}
else {
    print("Converted Number is Nil")
}


//Declaring Variable with Range

for i in 1..<10 {
    print("i = ",i)
}

print(" ")

for i in 1...10 {
    print("i = ",i)
}

// Array of Strings with square braces

let languages:[String]
languages = ["English","Spanish","French","Punjabi"]

for i in languages {
    print("languages = ",i)
}


let intarray:[Int]
intarray = [15,16,17,19,12,10]

for i in intarray {
    print("intarray = ",i)
}


var interval:Int = 5
for i in stride(from: 00, to: 50, by: interval)
{
    print(i," ",terminator:" ")
    
}



// Use values without storing into the memory

var answer:Int = 1

for _ in 1...5 {
    print ("Answer = ",answer)
    answer *= 5
}


  // While loop
var j = 1

while (j<10)
{
    print ("Value of J:",j)
    j = j + 1
}


repeat {
    print("Repeat: \(j)")
    j = j - 1
} while (j >= 0)





//Factorial

var pact = 1
var mult = 1
var i:Int

if (pact>10)
{
    for i in 1...10 {
    pact = i * 5
    print(pact)
    }
}
    
else
{
    for i in 1...5{
  mult=mult*i
    }
 print(mult)

}



var num1 = 100

switch num1 {
    
case 100:
    print("Num1 is 100")
    
case 10,15:
    print("Number is either 10 or 15")
case 5:
    print("Number is 5")
default:
    print("Number is not avlable")
}




