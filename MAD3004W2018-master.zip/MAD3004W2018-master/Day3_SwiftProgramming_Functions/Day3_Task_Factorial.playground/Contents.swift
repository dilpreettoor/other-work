//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func factorial(of num: Int) ->Int {
    if num == 1 {
        return 1
    } else {
        return num * factorial(of:num - 1)
    }
}
let result = factorial(of: 5)
print("The factorial number is \(result)")

