//: Playground - noun: a place where people can play
import UIKit

var str = "Hello, playground"

//Declaring a structure
struct project{
    var title = " "
    var hours = 0
    
    func display() {
        
        print("Project Title:", title)
        print("Total Work Hours:", hours)
        
    }
}


//Declaring instance of stuructures
var LMSProject = project(title: "Moodle", hours: 200)
print(LMSProject)

LMSProject.display()

LMSProject.hours = 300

LMSProject.display()



//Class Declaration

class Manager {
    var name : String = " "
    var productOwner : Bool = true
    var currentProjects = project()
}

//Creating instance of class
let mgrCanada = Manager()
mgrCanada.name = "PK"
mgrCanada.productOwner = true
mgrCanada.currentProjects = project(title:"sales reporting", hours:20)

print("MGR Canada name: ", mgrCanada.name)
print("MGR Canada Product Owner: ", mgrCanada.productOwner)
print("MGR Canada Current Project Title: ", mgrCanada.currentProjects.title)
print("MGR Canada Working Hours: ", mgrCanada.currentProjects.hours)



mgrCanada.currentProjects.title = "Manager Sales"
mgrCanada.currentProjects.hours = 40


print("MGR Canada name: ", mgrCanada.name)
print("MGR Canada Product Owner: ", mgrCanada.productOwner)
print("MGR Canada Current Project Title: ", mgrCanada.currentProjects.title)
print("MGR Canada Working Hours: ", mgrCanada.currentProjects.hours)

//Structures are Value Types

struct address {
    var street = "266 Yorkland Blvd"
    var city = "North York"
    var postalcode = "JH56TY"
}

var lambton = address()
print ("Lambton: ",lambton)

var cestar = lambton
print ("Cestar: ",cestar)

cestar.city = "Brampton"
cestar.postalcode = "L4TT3A"

print ("New Cestar: ",cestar)


print ("New Lambton: ",lambton)


//Classes are References Types
class institute{
    var street = "266 Yorkland Blvd"
    var city = "North York"
    var postalcode = "JH56TY"
}

var mylambton = institute()
print ("My Lambton Dtreet: ",mylambton.street)
print ("My Lambton City: ",mylambton.city)
print ("My Lambton Postal: ",mylambton.postalcode)

var mycestar = mylambton
print ("My Cestar: ",mycestar.street)
print ("My cestar City: ",mycestar.city)
print ("My cestar Postal: ",mycestar.postalcode)

mycestar.city = "New Yorkdale"
mycestar.postalcode = "146521"

print ("New My Lambton Dtreet: ",mylambton.street)
print ("New My Lambton City: ",mylambton.city)
print ("New My Lambton Postal: ",mylambton.postalcode)

print ("New My Cestar: ",mycestar.street)
print ("New My cestar City: ",mycestar.city)
print ("New My cestar Postal: ",mycestar.postalcode)


//Identical to ===
if mylambton === mycestar {
    print("Both classes are same")
}
else{
    print("Both Clasess are not same")
}


var yourcestar = institute()

if yourcestar === mycestar {
    print("Both classes are same")
}
else{
    print("Both Clasess are not same")
}


//object person

struct PersonAddress {
    var street = " "
    var city = " "
    var postalcode = " "
}

class Person {
    var name : String = " "
    var age : Int = 0
    var address = PersonAddress()
    var job: String = " "
}

var NewPerson = Person()

NewPerson.name = "Naveen"
NewPerson.age = 16
NewPerson.address.street = "Torrance Woods"
NewPerson.address.city = "Brampton, Ontario"
NewPerson.address.postalcode = "L6Y2V1"
NewPerson.job = "Designer"

print("New Person Name: ",NewPerson.name)
print("New Person Age: ",NewPerson.age)
print("New Person Address: ",NewPerson.address.street, NewPerson.address.city, NewPerson.address.postalcode)
print("New Person Job: ",NewPerson.job)


