//: Playground - noun: a place where people can play

import UIKit

//object person

struct PersonAddress {
    var street = " "
    var city = " "
    var postalcode = " "
}

class Person {
    var name : String = " "
    var age : Int = 0
    var address = PersonAddress()
    var job: String = " "
}

var NewPerson = Person()

NewPerson.name = "Naveen"
NewPerson.age = 16
NewPerson.address.street = "Torrance Woods"
NewPerson.address.city = "Brampton, Ontario"
NewPerson.address.postalcode = "L6Y2V1"
NewPerson.job = "Designer"

print("New Person Name: ",NewPerson.name)
print("New Person Age: ",NewPerson.age)
print("New Person Address: ",NewPerson.address.street, NewPerson.address.city, NewPerson.address.postalcode)
print("New Person Job: ",NewPerson.job)

