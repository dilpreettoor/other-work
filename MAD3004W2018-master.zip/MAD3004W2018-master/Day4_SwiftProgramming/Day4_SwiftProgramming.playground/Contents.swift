//: Playground - noun: a place where people can play
import UIKit

//Clousures

var months = [8,9,1,5,4,7,3,2,6]
print(months.sorted())

func reverse(_ s1: Int, _ s2: Int) -> Bool {
    return s1>s2
}

var reversedmonths = months.sorted(by: reverse)
print("Reversed Months",reversedmonths)

func increasing(_ s1: Int, _ s2: Int) -> Bool {
    return s1<s2
}

var increasingMonths = months.sorted(by: increasing)

print("Increasing Months: ",increasingMonths)

var reverseClosure = months.sorted( by: {
    (_ s1: Int, _ s2: Int) -> Bool in
    return s1>s2
})

print("Reverse Closure: ",reverseClosure)


//Inferring Parameter types from context
var inferTypes = months.sorted(by: {
    //(s1, s2) in return s1<s2
    (s1, s2) in s1<s2
    
})

print("inferTypes:",inferTypes)

//ShortHand Argument Names
print("Shorthand Argument:", months.sorted(by:{$0<$1}))


//Operator Methods
print("Operator Methods:", months.sorted(by: <))



var three = [1,3,4,6,8,9,15,16,18,19,25]
print("Three: ",three)

var modThree = three.filter({ $0 % 3 == 0})
print("ModThree:",modThree)

var evenThree = three.filter({ $0 % 2 == 0})
print ("Even Three: ",evenThree)

var oddThree = three.filter({ $0 % 2 != 0})
print ("Odd Three: ",oddThree)




//Nested Function CLosures

func makeIncrementer (forIncrement amout: Int) -> () -> Int {
    var runningTotal=0
    
    func incrementer() -> Int {
        runningTotal += amout
        return runningTotal
    }
    return incrementer
}

let incrementByTen = makeIncrementer(forIncrement: 10)

print("First Call: ",incrementByTen())
print("Second Call: ",incrementByTen())
print("Third Call: ",incrementByTen())


let incrementBySeven = makeIncrementer(forIncrement: 7)

print("First Call: ",incrementBySeven())
print("Second Call: ",incrementBySeven())
print("Third Call: ",incrementBySeven())

print("Ten Fourth Call: ",incrementByTen())


//Closures are reference Type
let incrementbySevenAgain = incrementBySeven
print("Increment by seven - 3: ",incrementbySevenAgain())


//AutoClosures
var errorList = [404,414,402,431,455,444]
print("Total Errors: ",errorList.count)

let debugger = {errorList.remove(at:0)}
print("Total Errors: ",errorList.count)

print("Now Solving: ",debugger())
print("Total Errors: ", errorList.count)
print("Error List: ",errorList)


func solve (error debugger: @autoclosure () -> Int) {
    print("Now Soving: ", debugger())
}

solve(error: errorList.remove(at: 0))
print("Error List:",errorList)

	
