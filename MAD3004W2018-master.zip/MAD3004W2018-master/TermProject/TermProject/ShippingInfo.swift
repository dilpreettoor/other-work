//
//  ShippingInfo.swift
//  TermProject
//
//  Created by MacStudent on 2018-02-05.
//  Copyright © 2018 LambtonCollege. All rights reserved.
//

import Foundation

class ShippingInfo {
    var ShippingID: Int?
    var ShippingType: String?
    var ShipppingCost: Int?
    var ShippingRegionID: Int?
    
    init()
    {
        self.ShippingID = 0
        self.ShippingType = ""
        self.ShipppingCost = 0
        self.ShippingRegionID = 0
        
    }
}
